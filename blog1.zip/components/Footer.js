export default function Footer() {
    return (
        <footer className="mt-3 py-4 bg-white shadow">
            <div className="container text-center">
                <small>Copyright &copy; AWANPC</small>
            </div>
        </footer>
    )
}