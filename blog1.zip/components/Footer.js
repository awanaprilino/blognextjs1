export default function Footer() {
    return (
        <footer class="mt-3 py-4 bg-white shadow">
            <div class="container text-center">
                <small>Copyright &copy; AWANPC</small>
            </div>
        </footer>
    )
}